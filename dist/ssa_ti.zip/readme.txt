Unzip this file into your Classic99\DSK1 folder or mount the disk image in DSK1.
To start it, select the EDITOR/ASSEMBLER cartridge.
Follow the menus to start Editor Assembler.
Select 5 LOAD PROGRAM FILE
Type: DSK1.BOOTSSA

Use Joystick 1 (arrow keys and TAB)

-- OR --

You can run under many emulators and on hardware as a cartridge (using FlashROM99 or a "non-inverted" bank switch cartridge board with a 32K EPROM) - use "SuperSpaceAcer32KB8.bin"

