This never got past the introduction sequence, and source code is lost.

Run as EA#5 - SSA2_A1 from files, or SSA2/A1 from the disk image.