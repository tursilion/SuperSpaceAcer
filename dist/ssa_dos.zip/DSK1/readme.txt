This is my original TI Super Space Acer game... it runs fine on the emulator under the Editor/Assembler or Supercart (which are the same cart as far as Ami99 cares). Speed is a bit fast on my P2-450, but playable. ;) Everything must stay in DSK1.

(Original README included for interest's sake)

"Super Space Acer Docs...8 May 1992"
----------------------------------
Thank you for buying Super Space Acer!!
It is my intention to continue to
release high-quality games for the
TI-99/4a home computer! Here are a
few features that were put in after
the manual was sent to be printed:

-the invincible shield that surrounds
your ship glows according to it's power.
It will start off bathing your ship in
pure white, then fade to yellow, and
red before fading out all together.
Be careful when your shield is red...
it could give out at any time!!

-the game MUST be loaded with the
BOOT program included on the disk.
BOOT itself may be run from ANY program
image loader. I have tested it with the
Editor/Assembler option #5, the Horizon
RamDisk Menu, and the DM1000 loaders,
with no problems. BOOT expects the
program to be in drive one, and the
disk should remain there to allow the
other files to be accessed.

-on the disk should be:
README! (this document file)
ACER_P
ACER_C (the title page, TI Artist)
BOOT (the program loader)
SSA - SSE (the program files)

---------------------------------------
As an added bonus, EA5 run "DEMO"
It's a bit slow on the emu. ;)
