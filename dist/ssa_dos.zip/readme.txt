19 Dec 00 - First release of SSAdx Arcade Port Version 2

This adds the following features:
-Lives remaining counter in the bottom middle of the screen
-MOD background music (need JGmod to compile source)
-Sample sound effects for explosions
